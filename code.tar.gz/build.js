import esbuild from "esbuild";
import path from "path";

esbuild.build({
  entryPoints: [path.join(process.cwd(), "src", "index.jsx")],
  bundle: true,
  outfile: path.join(process.cwd(), "dist", "bundle.js"),
  platform: "browser",
  format: "iife",
  define: {
    "process.env.NODE_ENV": '"production"'
  },
  loader: {
    ".js": "jsx",
    ".jsx": "jsx"
  },
  external: ["monday-sdk-js"]  // explicitly tell esbuild not to try bundling it
}).catch(() => process.exit(1));
