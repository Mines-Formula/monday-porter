function Home() {
    return (
        <>
            <h1 text-align="center">Home</h1>
            <p>There is nothing here, go to another page</p>
        </>
    )
}

export default Home;