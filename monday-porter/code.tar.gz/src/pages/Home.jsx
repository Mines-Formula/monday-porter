import { useEffect } from 'react'
import {
 SeamlessApiClient, ApiClient
} from "@mondaydotcomorg/api";

function Home() {
    useEffect(() => {
        async function getInfo() {
            /*const res = await fetch('/api/orderingQueue');
            const data = await res.json();
            console.log(data);*/
            const client = new SeamlessApiClient();
            const response = await client.request(`query { boards(ids: 9377407776) { name columns { title id } items_page( limit: 500 query_params: {order_by: [{column_id: "__creation_log__", direction: desc}]} ) { cursor items { id name column_values { text value __typename } } } } }`);
            console.log(response);
        }
        getInfo();
    }, []);

    return (
        <>
            <h1 text-align="center">Home</h1>
            <main>
                <p>There is nothing here, go to another page</p>
            </main>
        </>
    )
}

export default Home;